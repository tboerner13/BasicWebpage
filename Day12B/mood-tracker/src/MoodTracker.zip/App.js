import MoodTracker from './MoodTracker';
import './App.css';

function App() {
  return (
    <div className="App">
      <MoodTracker />
    </div>
  );
}

export default App;
