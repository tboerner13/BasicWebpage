import CardList from './CardList'
import "./App.css"

function App(){

  return(
  <div>
    <CardList /> 
  </div>
  );
}

export default App;
